package Controller;

import Model.EmailSender;
import View.SendEmail;
import javax.swing.JOptionPane;

public class EmailController {
    private SendEmail view;
    private EmailSender model;

    public EmailController(SendEmail view, EmailSender model) {
        this.view = view;
        this.model = model;
        this.view.setController(this);
    }

    public void sendEmail() {
        String to = view.getEmail();
        String subject = view.getSubject();
        String message = view.getMessage();

        if (to.isEmpty() || subject.isEmpty() || message.isEmpty()) {
            JOptionPane.showMessageDialog(view, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        boolean success = model.sendEmail(to, subject, message);
        if (success) {
            JOptionPane.showMessageDialog(view, "Email sent successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(view, "Failed to send email.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
