/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement; 
/**
 *
 * @author ASUS
 */
public class AddRecord {
    Statement stmt;
    Connection conn = null;
    ResultSet rs = null; 
     
public void Form(String NIC, String pName,String contactNo,String gender, String age,String Address,String email,String BloodType) { 
        try { 
        stmt = DBConnection.getStatementConnection(); 
        stmt.executeUpdate 
        ("INSERT INTO patient VALUES('"+NIC+"', '"+pName+"', '"+contactNo+"', '"+gender+"','"+age+"','"+Address+"','"+email+"','"+BloodType+"')"); 
        } catch (Exception e) { 
            e.printStackTrace(); 
        } 
   }
}