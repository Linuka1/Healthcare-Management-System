/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;
import javax.swing.JOptionPane; 
import java.util.Date;
/**
 *
 * @author ASUS
 */
public class PatientController {
    public static void Form(String NIC, String pName,String contactNo,String gender, String age,String Address,String email,String BloodType) { 
    new Model.AddRecord().Form(NIC,pName,contactNo,gender,age, Address,email,BloodType); 
        JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull", JOptionPane.INFORMATION_MESSAGE); 
} 

    public static void Form(String text, String text0, String gender, String age) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static void Form(String text, String text0, String text1, String gender, String age) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static void Form(String text, String text0, String text1, String text2, String gender, String text3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public static void Form(String text, String text0, String text1, String gender, String text2, String text3, String text4) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
