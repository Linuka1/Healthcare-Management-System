/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.sql.SQLException;

public class DBSearch {

    // Declare Statement object as Statement instead of Object
    private Statement stmt;
    private ResultSet rs;

    // Method to search students (fetch reports in this case)
    public ResultSet searchReports() { 
        try {
            // Get a statement from the DBConnection class
            stmt = DBConnection.getStatementConnection();
            
            // Execute the SQL query to fetch reports
            rs = stmt.executeQuery("SELECT * FROM reports");

        } catch (SQLException e) {
            // Print the exception message for debugging
            e.printStackTrace();
        }
        return rs;
    }
}
