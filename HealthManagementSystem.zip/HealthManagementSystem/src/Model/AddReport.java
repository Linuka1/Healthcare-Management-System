/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author heshi
 */
public class AddReport {
    Statement stmt;
public void Reports(String month,String pCount, String pStock,String dSchedules,String noOfAp, String revenue){
try{
stmt = DBConnection.getStatementConnection();
stmt.executeUpdate("INSERT INTO reports VALUES('"+month+"','"+pCount+"', '"+pStock+"', '"+dSchedules+"', '"+noOfAp+"', '"+revenue+"' )");
} catch(Exception e){
e.printStackTrace();
}
}
}
