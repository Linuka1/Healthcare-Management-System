/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;


import javax.swing.JOptionPane;

/**
 *
 * @author heshi
 */
public class ReportController {
     public static void Reports(String month,String pCount, String pStock,String dSchedules,String noOfAp, String revenue)
    {
        new Model.AddReport().Reports(month, pCount, pStock, dSchedules, noOfAp, revenue);
    JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);
    }

    public static void Reports(String string, String text, String text0, String text1, String text2) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
