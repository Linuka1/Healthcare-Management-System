package View;

import Model.DBConnection;
import Model.DBSearch;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.Date;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import javax.swing.table.DefaultTableModel;

public class DoctorViews extends javax.swing.JFrame {

    
    public DoctorViews() {
        initComponents();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        jList1 = new javax.swing.JList<>();
        jPanel1 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        doctorComboBox = new javax.swing.JComboBox<>();
        jLabel4 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();
        docID = new javax.swing.JTextField();
        availableTime = new javax.swing.JTextField();
        specialty = new javax.swing.JTextField();
        availableDays = new javax.swing.JTextField();
        docNameTxt = new javax.swing.JTextField();
        viewScheduleBtn = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        scheduleTbl = new javax.swing.JTable();
        addScheduleBtn = new javax.swing.JButton();
        updateScheduleBtn = new javax.swing.JButton();
        removeScheduleBtn = new javax.swing.JButton();

        jList1.setModel(new javax.swing.AbstractListModel<String>() {
            String[] strings = { "Item 1", "Item 2", "Item 3", "Item 4", "Item 5" };
            public int getSize() { return strings.length; }
            public String getElementAt(int i) { return strings[i]; }
        });
        jScrollPane1.setViewportView(jList1);

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(204, 255, 204));

        jLabel2.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel2.setText("Select the Doctor to view the details.");

        doctorComboBox.setBackground(new java.awt.Color(204, 255, 204));
        doctorComboBox.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        doctorComboBox.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Dr Dissanayake", "Dr Padmasiri", "Dr Padeniya", "Dr Meegama", "Dr Senadeera", "Dr Samarawickarama", "Dr Koswatte" }));
        doctorComboBox.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                doctorComboBoxActionPerformed(evt);
            }
        });

        jLabel4.setFont(new java.awt.Font("Times New Roman", 1, 36)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(0, 153, 0));
        jLabel4.setText("Doctor Details and Schedules");

        jLabel3.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel3.setText("Doctor ID: ");

        jLabel5.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel5.setText("Specialty: ");

        jLabel6.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel6.setText("Available Days:");

        jLabel7.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel7.setText("Available Time");

        jLabel8.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        jLabel8.setText("Doctor Name: ");

        docID.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        docID.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                docIDActionPerformed(evt);
            }
        });

        availableTime.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        availableTime.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                availableTimeActionPerformed(evt);
            }
        });

        specialty.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        specialty.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                specialtyActionPerformed(evt);
            }
        });

        availableDays.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        availableDays.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                availableDaysActionPerformed(evt);
            }
        });

        docNameTxt.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N

        viewScheduleBtn.setBackground(new java.awt.Color(102, 204, 0));
        viewScheduleBtn.setFont(new java.awt.Font("Times New Roman", 0, 24)); // NOI18N
        viewScheduleBtn.setText("View Schedule");
        viewScheduleBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                viewScheduleBtnActionPerformed(evt);
            }
        });

        scheduleTbl.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Appointment Time", "Appointment Date", "Patient Name", "Contact Number", "Gender"
            }
        ));
        jScrollPane2.setViewportView(scheduleTbl);

        addScheduleBtn.setBackground(new java.awt.Color(153, 255, 153));
        addScheduleBtn.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        addScheduleBtn.setText("Add a Schedule");
        addScheduleBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        addScheduleBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                addScheduleBtnActionPerformed(evt);
            }
        });

        updateScheduleBtn.setBackground(new java.awt.Color(153, 255, 153));
        updateScheduleBtn.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        updateScheduleBtn.setText("Update the Schedule");
        updateScheduleBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        updateScheduleBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                updateScheduleBtnActionPerformed(evt);
            }
        });

        removeScheduleBtn.setBackground(new java.awt.Color(153, 255, 153));
        removeScheduleBtn.setFont(new java.awt.Font("Times New Roman", 0, 18)); // NOI18N
        removeScheduleBtn.setText("Remove the Schedule");
        removeScheduleBtn.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        removeScheduleBtn.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                removeScheduleBtnActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(45, 45, 45)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 367, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(doctorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, 292, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel1Layout.createSequentialGroup()
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel3)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel7))
                                .addGap(58, 58, 58)
                                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(availableDays, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(docNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(docID, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(availableTime, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addGroup(jPanel1Layout.createSequentialGroup()
                                        .addComponent(specialty, javax.swing.GroupLayout.PREFERRED_SIZE, 336, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(163, 163, 163)
                                        .addComponent(viewScheduleBtn))))))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(23, 23, 23)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 710, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(addScheduleBtn)
                            .addComponent(updateScheduleBtn)
                            .addComponent(removeScheduleBtn)))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(255, 255, 255)
                        .addComponent(jLabel4)))
                .addContainerGap(24, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addComponent(jLabel4)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 42, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(doctorComboBox, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(docID, javax.swing.GroupLayout.PREFERRED_SIZE, 28, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(32, 32, 32)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(docNameTxt, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(23, 23, 23)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(specialty, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(viewScheduleBtn))
                .addGap(33, 33, 33)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(availableDays, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(41, 41, 41)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel7)
                    .addComponent(availableTime, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(addScheduleBtn)
                        .addGap(18, 18, 18)
                        .addComponent(updateScheduleBtn)
                        .addGap(18, 18, 18)
                        .addComponent(removeScheduleBtn)
                        .addGap(125, 125, 125))
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addGap(40, 40, 40)
                        .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 255, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(46, Short.MAX_VALUE))))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void doctorComboBoxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_doctorComboBoxActionPerformed
        String docName = (String)doctorComboBox.getSelectedItem();

        if (!docName.isEmpty()) {
            try {
                ResultSet rs = new DBSearch().searchDoctorByName(docName);

                if (rs.next()) {
                    docID.setText(rs.getString("docID"));
                    docNameTxt.setText(String.valueOf(rs.getString("docName")));
                    specialty.setText(String.valueOf(rs.getString("specialty")));
                    availableDays.setText(String.valueOf(rs.getString("availableDays")));
                    availableTime.setText(String.valueOf(rs.getString("availableTime")));

                } 
                else {
                    JOptionPane.showMessageDialog(this, "Doctor not found!", "Error", JOptionPane.ERROR_MESSAGE);

                }

                DBConnection.closeConnection(); // Close DB connection
            } 
            catch (Exception e) {
                e.printStackTrace();
                JOptionPane.showMessageDialog(this, "Database error!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } 
    }//GEN-LAST:event_doctorComboBoxActionPerformed

    private void availableTimeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_availableTimeActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_availableTimeActionPerformed

    private void specialtyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_specialtyActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_specialtyActionPerformed

    private void viewScheduleBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_viewScheduleBtnActionPerformed
        String docName = (String)doctorComboBox.getSelectedItem();
        ResultSet rs = new DBSearch().searchSchedules(docName);
        
        if(docName.isEmpty())
        {
            JOptionPane.showMessageDialog(this, "Please select a Doctor.");
            return;
        }
        DefaultTableModel dtm = (DefaultTableModel) scheduleTbl.getModel();
        dtm.setRowCount(0); 
        try
        {
            Vector v;
            while (rs.next())
            {
                v = new Vector();
                v.add(rs.getString("docName"));
                v.add(rs.getString("pName"));
                v.add(rs.getDate("appDate"));
                v.add(rs.getString("appTime"));
                v.add(rs.getString("email"));
                dtm.addRow(v); //Adds a row to the end of the model
            }
            DBConnection.closeConnection();
        }
        catch (Exception e) 
        {
            e.printStackTrace();
        }
    }//GEN-LAST:event_viewScheduleBtnActionPerformed

    private void availableDaysActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_availableDaysActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_availableDaysActionPerformed

    private void docIDActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_docIDActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_docIDActionPerformed

    private void addScheduleBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_addScheduleBtnActionPerformed
        AddDoctorSchedule addSchedule = new AddDoctorSchedule(); 
        addSchedule.setVisible(true); 
    }//GEN-LAST:event_addScheduleBtnActionPerformed

    private void updateScheduleBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_updateScheduleBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_updateScheduleBtnActionPerformed

    private void removeScheduleBtnActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_removeScheduleBtnActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_removeScheduleBtnActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(DoctorViews.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(DoctorViews.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(DoctorViews.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(DoctorViews.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new DoctorViews().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton addScheduleBtn;
    private javax.swing.JTextField availableDays;
    private javax.swing.JTextField availableTime;
    private javax.swing.JTextField docID;
    private javax.swing.JTextField docNameTxt;
    private javax.swing.JComboBox<String> doctorComboBox;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JList<String> jList1;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton removeScheduleBtn;
    private javax.swing.JTable scheduleTbl;
    private javax.swing.JTextField specialty;
    private javax.swing.JButton updateScheduleBtn;
    private javax.swing.JButton viewScheduleBtn;
    // End of variables declaration//GEN-END:variables
}