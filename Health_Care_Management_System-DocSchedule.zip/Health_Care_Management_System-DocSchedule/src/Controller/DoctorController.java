package Controller;

import java.sql.Time;
import java.util.Date;

public class DoctorController 
{
    public static void DoctorSchedule(String docName, String pName,Date appDate,String appTime,String email)
    {
        new Model.AddSchedule().AddDoctorSchedule((String)docName, pName, appDate, appTime, email);
        new Model.RemoveSchedule().removeDoctorSchedule((String)docName, pName, appDate, appTime, email);
        new Model.UpdateSchedule().updateSchedule((String)docName, pName, appDate, appTime, email);
        
        
        
    }
}
