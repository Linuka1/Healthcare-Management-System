package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Date;
import java.text.SimpleDateFormat;

public class RemoveSchedule {
    public static boolean removeDoctorSchedule(String docName, String pName, Date appDate, String appTime, String email) {
        Connection conn = null;
        PreparedStatement pstmt = null;

        try {
            // Convert Date to String format (assuming "yyyy-MM-dd" format)
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = sdf.format(appDate);

            // Get database connection
            conn = DBConnection.getConnection();

            // Correct SQL query
            String sql = "DELETE FROM doctor_schedule WHERE docName = ? AND pName = ? AND appDate = ? AND appTime = ? AND email = ?";
            pstmt = conn.prepareStatement(sql);
            pstmt.setString(1, docName);
            pstmt.setString(2, pName);
            pstmt.setString(3, formattedDate);
            pstmt.setString(4, appTime);
            pstmt.setString(5, email);

            // Execute deletion and check if any row was affected
            int rowsDeleted = pstmt.executeUpdate();
            return rowsDeleted > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        } finally {
            // Close resources safely
            try {
                if (pstmt != null) pstmt.close();
                if (conn != null) conn.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
