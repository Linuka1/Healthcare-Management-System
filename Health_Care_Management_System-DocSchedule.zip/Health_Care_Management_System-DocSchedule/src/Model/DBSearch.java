//Doctor Schedule DBSearch
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBSearch {
    Statement stmt;
    ResultSet rs;
    PreparedStatement pst;
    Connection conn;
    
    public ResultSet searchDoctorByName(String docName) {
        
        try {
            // Get the connection from DBConnection class
            conn = DBConnection.getConnection();
            
            // Proper SQL query with placeholder for the doctor name
            String query = "SELECT * FROM doctor WHERE docName = ?";
            pst = conn.prepareStatement(query);
            
            // Set the value of docName in the prepared statement
            pst.setString(1, docName);
            
            // Execute the query
            rs = pst.executeQuery();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return rs;
    }
    
    public ResultSet searchProducts(String drugCode) {
        Connection conn = null;
        PreparedStatement pst = null;
        
        try {
            // Get the connection from DBConnection class
            conn = DBConnection.getConnection();
            
            // Proper SQL query with placeholder for the drugCode
            String query = "SELECT * FROM product WHERE id = ?";
            pst = conn.prepareStatement(query);
            
            
            pst.setString(1, drugCode);
            
            // Execute the query
            rs = pst.executeQuery();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return rs;
    }
    
    public ResultSet searchProduct() {
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM product");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return rs;
    }
    
    public ResultSet searchSchedules(String docname){
        try{
            String docName = docname;
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM doctor_schedule WHERE docName = '" + docName + "'");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return rs;
    }
}

