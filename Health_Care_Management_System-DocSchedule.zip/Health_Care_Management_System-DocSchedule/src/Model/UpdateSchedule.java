package Model;

import java.sql.*;
import java.text.SimpleDateFormat;

public class UpdateSchedule {
    
    public boolean updateSchedule(String docName, String pName, java.util.Date appDate, String appTime, String email) {
        // Update the schedule for the doctor in the database
        Connection conn = null;
        PreparedStatement pstmt = null;
        
        try {
            // Step 1: Establish connection
            conn = DBConnection.getConnection();

            // Step 2: Format the appointmentDate for SQL
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String formattedDate = sdf.format(appDate);

            // Step 3: Create SQL query to update the schedule
            String sql = "UPDATE doctor_schedule SET docName = ? AND pName = ? AND appDate = ? AND appTime = ? AND email = ?";
            pstmt = conn.prepareStatement(sql);
            
            // Step 4: Set the parameters for the prepared statement
            pstmt.setString(1, docName);
            pstmt.setString(2, pName);
            pstmt.setString(3, formattedDate);
            pstmt.setString(4, appTime);
            pstmt.setString(5, email);
            
            // Step 5: Execute the update query
            int rowsUpdated = pstmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                System.out.println("Schedule updated successfully.");
                return true;
            } else {
                System.out.println("No schedule found to update.");
                return false;
            }
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        } finally {
            // Step 6: Close resources
            try {
                if (pstmt != null) {
                    pstmt.close();
                }
                if (conn != null) {
                    conn.close();
                }
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}
