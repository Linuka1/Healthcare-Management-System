package Controller;

import Model.DataBaseConnection;
import Model.LoginDBSearch;
import View.Home;
import java.awt.Frame;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import View.Login;
import View.Main_menu;
public class LoginController {
public static void adminlogin(String usName, String pass) {
 try {
 String username = null; 
 String password = null; 
 ResultSet rs = new LoginDBSearch().searchLogin(usName);
//Process the Query
 while (rs.next()) {
 //assign database username and password to the variable    
username = rs.getString("username"); 
password = rs.getString("password"); 
 }
 if (username != null && password != null) {
 if (password.equals(pass)) {
 System.out.println("Login Successfull");
 new Main_menu().setVisible(true);
 } else {
JOptionPane.showMessageDialog(null, "Please check the credentials", "Error", JOptionPane.ERROR_MESSAGE);
 }
 } else {
JOptionPane.showMessageDialog(null, "Please check the Credentials", "Error", JOptionPane.ERROR_MESSAGE);
 }
 DataBaseConnection.closeCon();
 } catch (SQLException ex) { 
Logger.getLogger(LoginController.class.getName()).log(Level.SEVERE, null, ex);
 }
 }
}
