package Controller;

import javax.swing.JOptionPane;

public class EdetailsController {
    
    // Validate fields method
    public boolean validateFields(String NIC, String pName, String contactNo, String gender, String age, String Address, String email, String BloodType) {
        
        if (NIC.isEmpty() || pName.isEmpty() || contactNo.isEmpty() || gender.isEmpty() || age.isEmpty() || Address.isEmpty() || email.isEmpty() || BloodType.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill all fields before submitting.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;  
        }
        return true;
       
    }

    
    public static void EnterDetails(String NIC, String pName, String contactNo, String gender, String age, String Address, String email, String BloodType) {
        
        // Validate the fields before proceeding
        EdetailsController controller = new EdetailsController();
        if (controller.validateFields(NIC, pName, contactNo, gender, age, Address, email, BloodType)) {
            
            //insert the record 
            new Model.AddPatientRecord().EnterDetails(NIC, pName, contactNo, gender, age, Address, email, BloodType);
            
            // Show success message
            JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successful", JOptionPane.INFORMATION_MESSAGE);
             
        }
    }
}
