/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import java.util.Date;
import javax.swing.JOptionPane;

/**
 *
 * @author Tharindu
 */
public class AppointmentController {
     public boolean validateFields(String pName, String email, String Doc, Date appointmentDay, String apTime ,String concern) {
        
        if (pName.isEmpty() || email.isEmpty() || appointmentDay == null || concern.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please fill all fields before submitting.", "Input Error", JOptionPane.ERROR_MESSAGE);
            return false;  
        }
        return true;
       
    }

    // Method to handle the appointment details and insertion
    public static void EnterDetails(String pName, String email, String Doc, Date appointmentDay, String apTime ,String concern){
        
        // Validate the fields before proceeding
        AppointmentController controller = new AppointmentController();
        if (controller.validateFields(pName, email, Doc, appointmentDay, apTime, concern)) {
            
            //insert the record 
            new Model.AddAppointment().EnterDetails(pName, email, Doc, appointmentDay, apTime, concern);
            
            // Show success message
            JOptionPane.showMessageDialog(null, "New Record has been inserted", "Successful", JOptionPane.INFORMATION_MESSAGE);
        }
    }        
}

