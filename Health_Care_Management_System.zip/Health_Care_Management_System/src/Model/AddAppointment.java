package Model;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddAppointment {
    Statement stmt;

    public void EnterDetails(String pName, String email, String Doc, Date appointmentDay, String apTime ,String concern) {
        try {
            stmt = DataBaseConnection.getStatementConnection();
            
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
            String appointmentDateFormatted = sdf.format(appointmentDay);
            
            
            
            
            String query = "INSERT INTO appointments (pName, email, Doc, appointmentDay, appointmentTime, concern) " +
                           "VALUES (?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = (PreparedStatement) stmt.getConnection().prepareStatement(query);
            preparedStatement.setString(1, pName);
            preparedStatement.setString(2, email);
            preparedStatement.setString(3, Doc);
            preparedStatement.setString(4, appointmentDateFormatted);
            preparedStatement.setString(5, apTime);
            preparedStatement.setString(6, concern);
            ;
            
            // Execute the update
            preparedStatement.executeUpdate();
            

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
