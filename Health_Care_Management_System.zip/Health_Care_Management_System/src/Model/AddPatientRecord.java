package Model;

import java.sql.*;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddPatientRecord {
    Statement stmt;

    public void EnterDetails(String NIC, String pName, String contactNo, String gender, String age, String Address, String email, String BloodType) {
        try {
            stmt = DataBaseConnection.getStatementConnection();
            
            
            
            
            String query = "INSERT INTO patients (NIC, pName, contactNo, gender, age, Address, email, BloodType) " +
                           "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";
            PreparedStatement preparedStatement = (PreparedStatement) stmt.getConnection().prepareStatement(query);
            preparedStatement.setString(1, NIC);
            preparedStatement.setString(2, pName);
            preparedStatement.setString(3, contactNo);
            preparedStatement.setString(4, gender);
            preparedStatement.setString(5, age);
            preparedStatement.setString(6, Address);
            preparedStatement.setString(7, email);
            preparedStatement.setString(8, BloodType);
            
            // Execute the update
            preparedStatement.executeUpdate();
            

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
