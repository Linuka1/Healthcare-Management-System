package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddSchedule {
    public void AddDoctorSchedule(String docName, String pName, Date appDate, String appTime, String email) {
        try {
            Connection conn = DocPharDBConnection.getConnection();

            // Insert using PreparedStatement to prevent SQL injection
            String query = "INSERT INTO doctor_schedule (docName, pName, appDate, appTime, email) VALUES (?, ?, ?, ?, ?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, docName);
            pst.setString(2, pName);
            java.sql.Date sqlExDate = new java.sql.Date(appDate.getTime());
            pst.setDate(3, sqlExDate);
            pst.setString(4, appTime);
            pst.setString(5, email);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Schedule added successfully!");
            } else {
                System.out.println("Failed to add schedule.");
            }

            // Close resources
            pst.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
