package Controller;

import java.util.Date;

public class ProductController {
    public static void products(String newDName, String newPrice, Date exDate, int qty)
    {
        new Model.AddProducts().products(newDName, newPrice , exDate, qty);
        
    }
    
}
