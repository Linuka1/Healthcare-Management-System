package Model;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DBConnection {
    private static Connection conn;

    public static Connection getConnection() {
        try {
            if (conn == null || conn.isClosed()) {
                String url = "jdbc:mysql://localhost:3306/healthcaremanagementsystem";
                conn = DriverManager.getConnection(url, "root", "");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return conn;
    }

    public static void closeConnection() {
        try {
            if (conn != null && !conn.isClosed()) {
                conn.close();
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    public static Statement getStatementConnection(){
        Statement stat = null;
        try{
            String url = "jdbc:mysql://localhost:3306/studentdb";
            conn = DriverManager.getConnection(url, "root", "");
            stat = conn.createStatement();
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return stat;
    }
}

