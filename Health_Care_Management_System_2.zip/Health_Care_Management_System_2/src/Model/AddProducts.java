package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.util.Date;

public class AddProducts {
    
    public void products(String newDName, String newPrice , Date exDate, int qty){
        try {
            Connection conn = DBConnection.getConnection();
            
            String query = "INSERT INTO product (drugName , price , exDate, qty) VALUES (?,?,?,?)";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, newDName);
            pst.setString(2, newPrice);
            java.sql.Date sqlExDate = new java.sql.Date(exDate.getTime());
            pst.setDate(3, sqlExDate);
            pst.setInt(4, qty);

            int rowsAffected = pst.executeUpdate();
            if (rowsAffected > 0) {
                System.out.println("Schedule added successfully!");
            } else {
                System.out.println("Failed to add schedule.");
            }

            pst.close();
            conn.close();
        } 
        catch (Exception e) {
            e.printStackTrace();
        }
    }
}
