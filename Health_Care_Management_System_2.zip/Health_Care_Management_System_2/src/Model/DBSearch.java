//Doctor Schedule DBSearch
package Model;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class DBSearch {
    Statement stmt;
    ResultSet rs;
    PreparedStatement pst;
    Connection conn;
    
    
    public ResultSet searchProducts(String drugCode) {
        Connection conn = null;
        PreparedStatement pst = null;
        
        try {
            // Get the connection from DBConnection class
            conn = DBConnection.getConnection();
            
            // Proper SQL query with placeholder for the drugCode
            String query = "SELECT * FROM product WHERE id = ?";
            pst = conn.prepareStatement(query);
            
            
            pst.setString(1, drugCode);
            
            // Execute the query
            rs = pst.executeQuery();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return rs;
    }
    
    public ResultSet searchProduct() {
        try{
            stmt = DBConnection.getStatementConnection();
            rs = stmt.executeQuery("SELECT * FROM product");
        }
        catch(Exception e){
            e.printStackTrace();
        }
        return rs;
    }
    
    
}

